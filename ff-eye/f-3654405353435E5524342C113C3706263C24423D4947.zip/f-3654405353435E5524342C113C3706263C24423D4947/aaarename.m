% Get the current directory path
folderPath = pwd;

% List all .png files in the folder
files = dir(fullfile(folderPath, '*.png'));

% Loop through each .png file in the folder
for i = 1:length(files)
    % Extract the current file name
    currentFileName = files(i).name;
    
    % Define your custom filename modification logic here
    % Example: prepend 'renamed_' to the original file name
    modifiedFileName = ['f-220718AZMSSEcGPM1m', currentFileName(8:end)];
    
    % Full path for current and new file names
    currentFullPath = fullfile(folderPath, currentFileName);
    newFullPath = fullfile(folderPath, modifiedFileName);
    
    % Rename the file
    movefile(currentFullPath, newFullPath);
    
    % Print the old and new names to confirm the changes
    %fprintf('Renamed "%s" to "%s"\n', currentFileName, modifiedFileName);
end
